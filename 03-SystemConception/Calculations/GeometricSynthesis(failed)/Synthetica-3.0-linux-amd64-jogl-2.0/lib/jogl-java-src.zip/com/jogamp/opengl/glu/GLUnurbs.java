package com.jogamp.opengl.glu;

/**
 * Wrapper for a GLU NURBS object.
 */

public interface GLUnurbs {
}
